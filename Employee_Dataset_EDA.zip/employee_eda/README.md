# Employee Dataset — Exploratory Data Analysis

Full EDA on a 50-row employee dataset covering demographic group, age, lifestyle habits, and salary. Built and tested end-to-end in Google Colab.

## 📁 Project Structure
```
employee_eda/
├── Employee_EDA.ipynb     # Main notebook (Colab-ready, pre-executed)
├── Employee_Dataset.csv   # Source data
├── images/                # Exported charts (for README / LinkedIn / portfolio use)
└── README.md
```

## 📊 Dataset
| Column | Description |
|---|---|
| `id` | Unique employee identifier |
| `groups` | Employee group category (A, B, AB, O) |
| `age` | Age in years |
| `healthy_eating` | Self-reported healthy eating score (~1–10) |
| `active_lifestyle` | Self-reported activity score (~1–10) |
| `salary` | Salary |

50 rows, 6 columns, **no missing values, no duplicates**.

## 🔍 What the Notebook Covers
1. Data loading & quality checks (nulls, duplicates, dtypes)
2. Summary statistics
3. Univariate distributions (age, salary, lifestyle scores, group counts)
4. Correlation heatmap + pairplot
5. Bivariate analysis of salary vs. age / healthy eating / active lifestyle
6. Group-wise salary comparison (boxplot + summary table)
7. Age-bracket salary analysis
8. IQR-based outlier detection on salary
9. Key insights summary + suggested next steps

## 🧠 Key Insights
- **Healthy eating is the strongest predictor of salary** in this dataset (r ≈ 0.76).
- **Age correlates positively with salary** (r ≈ 0.59), consistent with seniority-based pay growth.
- **Active lifestyle score correlates negatively with salary** (r ≈ -0.50) — a counter-intuitive signal worth further investigation.
- **Group O** employees earn the most on average; **Group A** is the largest group but has the lowest average salary.
- No extreme outliers detected in salary via IQR method.

## ▶️ How to Run
1. Open `Employee_EDA.ipynb` in [Google Colab](https://colab.research.google.com/).
2. Upload `Employee_Dataset.csv` when prompted (or place it in the same directory).
3. Run all cells (`Runtime → Run all`).

## 🛠️ Tech Stack
`pandas` · `numpy` · `matplotlib` · `seaborn`

## 👤 Author
**Adarsh Mane**
[GitHub](https://github.com/adarshmane04) · [LinkedIn](https://linkedin.com/in/adarsh-mane-653976376)
